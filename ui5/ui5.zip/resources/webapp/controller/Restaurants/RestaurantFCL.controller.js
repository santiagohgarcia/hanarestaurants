sap.ui.define([
	"restaurants/ui5/controller/BaseController"
], function(BaseController) {
	"use strict";

	return BaseController.extend("restaurants.ui5.controller.Restaurants.RestaurantFCL", {

		onInit: function() {
			this.getRouter().getRoute("Tables").attachMatched(this._attachTablesMatched.bind(this));
			this.getRouter().getRoute("Menu").attachMatched(this._attachMenuMatched.bind(this));
			this.getRouter().getRoute("TableDetail").attachMatched(this._attachTableDetailMatched.bind(this));
			this.getRouter().getRoute("PendingOrders").attachMatched(this._attachPendingOrdersMatched.bind(this));
		},

		_attachTablesMatched: function() {
			this.getModel("view").setProperty("/layout", sap.f.LayoutType.OneColumn);
		},

		_attachMenuMatched: function() {
			this.getModel("view").setProperty("/layout", sap.f.LayoutType.OneColumn);
		},

		_attachTableDetailMatched: function() {
			this.getModel("view").setProperty("/layout", sap.f.LayoutType.TwoColumnsBeginExpanded);
			this.byId("fcl").toMidColumnPage(this.byId("tableDetail").getId());
		},

		_attachPendingOrdersMatched: function() {
			this.getModel("view").setProperty("/layout", sap.f.LayoutType.TwoColumnsBeginExpanded);
			this.byId("fcl").toMidColumnPage(this.byId("pendingOrders").getId());
		}

	});
});