sap.ui.define([
	"restaurants/ui5/controller/BaseController",
	"restaurants/ui5/model/formatter",
	"restaurants/ui5/model/types"
], function(BaseController, formatter, types) {
	"use strict";

	return BaseController.extend("restaurants.ui5.controller.Restaurants.PendingOrders", {

		formatter: formatter,
		types: types,

		onInit: function() {
			this.getRouter().getRoute("PendingOrders").attachMatched(this._attachPendingOrdersMatched.bind(this));
		},

		_attachPendingOrdersMatched: function(evt) {
			var args = evt.getParameter("arguments");
			this.getView().bindElement({
				path: `/Restaurants(RestaurantId=${args.RestaurantId})`,
				model: "restaurants"
			});
		},

		onClose: function() {
			this.onNavBack();
		}

	});
});