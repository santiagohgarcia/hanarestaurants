sap.ui.define([
	"restaurants/ui5/controller/BaseController",
	"restaurants/ui5/model/formatter",
	"restaurants/ui5/model/types"
], function(BaseController, formatter, types) {
	"use strict";

	return BaseController.extend("restaurants.ui5.controller.Orders.OrderDetail", {
		types: types,
		formatter: formatter,
		onInit: function() {
			this.getRouter().getRoute("OrderDetail").attachMatched(this._attachTableDetailMatched.bind(this));
		},

		_attachTableDetailMatched: function(evt) {
			var args = evt.getParameter("arguments");
			this.getView().bindElement({
				path: "/Orders(RestaurantId=" + args.RestaurantId + ",RestaurantTableId=" + args.RestaurantTableId + ",RestaurantOrderId=" +
					args.RestaurantOrderId + ")",
				parameters: {
					expand: "Product,Customer,Status"	
				},
				model: "restaurants"
			});
		},

		onClose: function() {
			var ctx = this.getView().getBindingContext("restaurants");
			this.getRouter().navTo("Tables", {
				RestaurantId: ctx.getProperty("RestaurantId")
			}, true);
		}

	});
});