sap.ui.define([
	"restaurants/ui5/controller/BaseDialog",
	"restaurants/ui5/controller/BaseController",
	"restaurants/ui5/utils/Validator",
	"restaurants/ui5/model/types",
	"restaurants/ui5/model/models",
	"sap/m/UploadCollectionParameter"
], function(BaseDialog, BaseController, Validator, types, models, UploadCollectionParameter) {
	"use strict";

	return BaseDialog.extend("restaurants.ui5.controller.Menu.Product.ProductDialog", {
		types: types,

		getDialogId: function() {
			return "productDialog";
		},

		getFragmentId: function() {
			return "restaurants.ui5.view.Menu.Product.ProductDialog";
		},

		getNewContext: function(ctx) {
			if (ctx["Category.CategoryId"]) {
				models.getNewProductId() //TODO: change this for AWAIT!!
					.then(response => {
						ctx.ProductId = response.ProductId;
						ctx.Images = [];
						ctx = this._dialog.getModel("restaurants").createEntry("/Products", {
							properties: ctx
						});
						this._dialog.setBindingContext(ctx, "restaurants");
					});
			} else {
				return ctx;
			}
		},

		getFieldGroup: function() {
			return "productFields";
		},

		onSave: function() {
			if (Validator.isValid(this.getFieldGroup(), this._dialog)) {
				this._view.byId("uploadCollection").upload();
			}
		},

		onUploadComplete: function() {
			BaseDialog.prototype.onSave.apply(this);
		},

		onBeforeUploadStarts: function(evt) {
			var addParameterFn = evt.getParameter("addHeaderParameter");
			var product = this._dialog.getBindingContext("restaurants").getObject();
			addParameterFn(new UploadCollectionParameter({
				name: "FileName",
				value: evt.getParameter("fileName")
			}));
			addParameterFn(new UploadCollectionParameter({
				name: "ProductId",
				value: product.ProductId
			}));
			/*
						addParameterFn(new UploadCollectionParameter({
							name: "Content-Type",
							value: "text/plain;charset=UTF-8"
						}));*/
		},

		success: function() {
			var productCtx = this._dialog.getBindingContext("restaurants");
			BaseController.prototype.showMessageToast("ProductDialog_ProductSaved", [productCtx.getProperty("ProductId")]);
			BaseDialog.prototype.success.apply(this);
		},

		onTypeMissmatch: function() {
			BaseController.prototype.showMessageToast("ProductDialog_ImageTypeMissmatch");
		}
	});

});