sap.ui.define([
	"restaurants/ui5/controller/BaseController",
	"restaurants/ui5/model/formatter",
	"restaurants/ui5/model/types",
	"restaurants/ui5/model/models",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function(BaseController, formatter, types, models, Filter, FO) {
	"use strict";

	return BaseController.extend("restaurants.ui5.controller.Tables.TableDetail", {
		types: types,

		formatter: formatter,

		onInit: function() {
			this.getRouter().getRoute("TableDetail").attachMatched(this._attachTableDetailMatched.bind(this));
		},

		_attachTableDetailMatched: function(evt) {
			var args = evt.getParameter("arguments");
			this.getView().bindElement({
				path: `/Tables(RestaurantId=${args.RestaurantId},RestaurantTableId=${args.RestaurantTableId})`,
				parameters: {
					expand: "Orders"
				},
				model: "restaurants"
			});
		},

		onClose: function() {
			this.onNavBack();
		},

		onPressOrder: function(evt) {
			var order = evt.getSource().getBindingContext("restaurants").getObject();
			this.getRouter().navTo("OrderDetail", {
				RestaurantId: order.RestaurantId,
				RestaurantTableId: order.RestaurantTableId,
				RestaurantOrderId: order.RestaurantOrderId
			});
		},

		onEditTable: function(evt) {
			var tableCtx = evt.getSource().getBindingContext("restaurants");
			this.openTableDialog(tableCtx);
		},

		onDeleteTable: function(evt) {
			var tableCtx = evt.getSource().getBindingContext("restaurants");
			var restaurantId = tableCtx.getProperty("RestaurantId");
			var tableId = tableCtx.getProperty("RestaurantTableId");
			this.getModel("restaurants").remove(tableCtx.getPath(), {
				success: function() {
					this.showMessageToast("TableDialog_TableDeleted", [tableId]);
					this.getModel("restaurants").refresh();
					this.getRouter().navTo("Tables", {
						RestaurantId: restaurantId
					}, true);
				}.bind(this)
			});
		},

		onSelectStatusTab: function(evt) {
			var selectedKey = evt.getParameter("selectedKey");
			var filters = [];
			if (selectedKey !== "active") {
				filters.push(new Filter("Status.StatusId", FO.EQ, Number(selectedKey)));
			}
			this.byId("tableOrderList").getBinding("items").filter(filters);
		},

		onPressReady: function(evt) {
			var orderCtx = evt.getSource().getBindingContext("restaurants");
			models.changeOrderStatus(orderCtx, 2) //Ready TODO: change for constants
				.then(() => {
					this.showMessageToast("Order_OrderReady", [orderCtx.getProperty("RestaurantOrderId")]);
					this.getModel("restaurants").refresh();
				});
		},

		onPressCancel: function(evt) {
			var orderCtx = evt.getSource().getBindingContext("restaurants");
			models.changeOrderStatus(orderCtx, 4) //Cancelled TODO: change for constants
				.then(() => {
					this.showMessageToast("Order_OrderCancelled", [orderCtx.getProperty("RestaurantOrderId")]);
					this.getModel("restaurants").refresh();
				});
		},

		onExpandPanel: function(evt) {
			var panel = evt.getSource();
			var expanded = evt.getParameter("expand");
			panel.getHeaderToolbar().getContent().forEach(cont => cont.setVisible(!expanded));
		},

		onAddOrder: function(evt) {
			var restaurantTable = evt.getSource().getBindingContext("restaurants").getObject();
			this.openOrderDialog({
				RestaurantId: restaurantTable.RestaurantId,
				RestaurantTableId: restaurantTable.RestaurantTableId
			});
		},

		onPressCloseTable: function(evt) {
			var restaurantTable = evt.getSource().getBindingContext("restaurants").getObject();
			models.closeTable(restaurantTable.RestaurantId, restaurantTable.RestaurantTableId)
				.then(() => {
					this.showMessageToast("TableDetail_TableClosed", [restaurantTable.RestaurantTableId]);
					this.getModel("restaurants").refresh();
				});
		}

	});
});